//
//  Sending_HTTP_PUT_Requests_with_NSURLConnectionTests.m
//  Sending HTTP PUT Requests with NSURLConnectionTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Sending_HTTP_PUT_Requests_with_NSURLConnectionTests : XCTestCase

@end

@implementation Sending_HTTP_PUT_Requests_with_NSURLConnectionTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
