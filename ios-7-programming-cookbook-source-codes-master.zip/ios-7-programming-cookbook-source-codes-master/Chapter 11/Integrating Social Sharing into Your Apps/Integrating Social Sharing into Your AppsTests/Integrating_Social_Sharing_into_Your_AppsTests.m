//
//  Integrating_Social_Sharing_into_Your_AppsTests.m
//  Integrating Social Sharing into Your AppsTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Integrating_Social_Sharing_into_Your_AppsTests : XCTestCase

@end

@implementation Integrating_Social_Sharing_into_Your_AppsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
