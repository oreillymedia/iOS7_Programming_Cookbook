//
//  Modifying_a_URL_Request_with_NSMutableURLRequestTests.m
//  Modifying a URL Request with NSMutableURLRequestTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Modifying_a_URL_Request_with_NSMutableURLRequestTests : XCTestCase

@end

@implementation Modifying_a_URL_Request_with_NSMutableURLRequestTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
