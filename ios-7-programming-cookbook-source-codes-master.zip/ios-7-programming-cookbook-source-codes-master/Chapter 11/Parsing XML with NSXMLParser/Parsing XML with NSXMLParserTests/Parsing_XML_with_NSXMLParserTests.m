//
//  Parsing_XML_with_NSXMLParserTests.m
//  Parsing XML with NSXMLParserTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Parsing_XML_with_NSXMLParserTests : XCTestCase

@end

@implementation Parsing_XML_with_NSXMLParserTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
