//
//  Introduction_to_Audio_and_VideoTests.m
//  Introduction to Audio and VideoTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Introduction_to_Audio_and_VideoTests : XCTestCase

@end

@implementation Introduction_to_Audio_and_VideoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
