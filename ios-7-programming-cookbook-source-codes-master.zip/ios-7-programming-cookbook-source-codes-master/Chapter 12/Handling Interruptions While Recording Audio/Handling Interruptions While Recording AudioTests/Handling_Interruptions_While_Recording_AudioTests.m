//
//  Handling_Interruptions_While_Recording_AudioTests.m
//  Handling Interruptions While Recording AudioTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Handling_Interruptions_While_Recording_AudioTests : XCTestCase

@end

@implementation Handling_Interruptions_While_Recording_AudioTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
