//
//  Playing_Audio_over_Other_Active_SoundsTests.m
//  Playing Audio over Other Active SoundsTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Playing_Audio_over_Other_Active_SoundsTests : XCTestCase

@end

@implementation Playing_Audio_over_Other_Active_SoundsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
