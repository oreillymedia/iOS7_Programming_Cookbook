//
//  Capturing_Thumbnails_from_Video_FilesTests.m
//  Capturing Thumbnails from Video FilesTests
//
//  Created by Vandad NP on 24/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Capturing_Thumbnails_from_Video_FilesTests : XCTestCase

@end

@implementation Capturing_Thumbnails_from_Video_FilesTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
