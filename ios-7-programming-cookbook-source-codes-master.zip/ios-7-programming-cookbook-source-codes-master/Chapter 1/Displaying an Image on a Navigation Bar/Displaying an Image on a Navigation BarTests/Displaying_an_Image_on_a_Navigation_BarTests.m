//
//  Displaying_an_Image_on_a_Navigation_BarTests.m
//  Displaying an Image on a Navigation BarTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Displaying_an_Image_on_a_Navigation_BarTests : XCTestCase

@end

@implementation Displaying_an_Image_on_a_Navigation_BarTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
