//
//  Creating_and_Using_Switches_with_UISwitchTests.m
//  Creating and Using Switches with UISwitchTests
//
//  Created by Vandad NP on 22/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Creating_and_Using_Switches_with_UISwitchTests : XCTestCase

@end

@implementation Creating_and_Using_Switches_with_UISwitchTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
