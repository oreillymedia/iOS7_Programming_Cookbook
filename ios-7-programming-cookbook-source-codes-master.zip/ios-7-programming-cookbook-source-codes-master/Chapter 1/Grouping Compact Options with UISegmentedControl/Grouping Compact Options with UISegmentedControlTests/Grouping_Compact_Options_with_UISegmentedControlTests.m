//
//  Grouping_Compact_Options_with_UISegmentedControlTests.m
//  Grouping Compact Options with UISegmentedControlTests
//
//  Created by Vandad NP on 22/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Grouping_Compact_Options_with_UISegmentedControlTests : XCTestCase

@end

@implementation Grouping_Compact_Options_with_UISegmentedControlTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
