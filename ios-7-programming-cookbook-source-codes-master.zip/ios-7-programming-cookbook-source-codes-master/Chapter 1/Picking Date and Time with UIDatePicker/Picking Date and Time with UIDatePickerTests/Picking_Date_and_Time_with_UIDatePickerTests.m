//
//  Picking_Date_and_Time_with_UIDatePickerTests.m
//  Picking Date and Time with UIDatePickerTests
//
//  Created by Vandad NP on 22/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Picking_Date_and_Time_with_UIDatePickerTests : XCTestCase

@end

@implementation Picking_Date_and_Time_with_UIDatePickerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
