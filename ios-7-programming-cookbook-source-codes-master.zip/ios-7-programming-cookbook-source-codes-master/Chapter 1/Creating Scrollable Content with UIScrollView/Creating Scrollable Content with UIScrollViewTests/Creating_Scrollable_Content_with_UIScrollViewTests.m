//
//  Creating_Scrollable_Content_with_UIScrollViewTests.m
//  Creating Scrollable Content with UIScrollViewTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Creating_Scrollable_Content_with_UIScrollViewTests : XCTestCase

@end

@implementation Creating_Scrollable_Content_with_UIScrollViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
