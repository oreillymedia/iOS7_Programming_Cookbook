//
//  Accepting_User_Text_Input_with_UITextFieldTests.m
//  Accepting User Text Input with UITextFieldTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Accepting_User_Text_Input_with_UITextFieldTests : XCTestCase

@end

@implementation Accepting_User_Text_Input_with_UITextFieldTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
