//
//  Implementing_Navigation_with_UINavigationControllerTests.m
//  Implementing Navigation with UINavigationControllerTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Implementing_Navigation_with_UINavigationControllerTests : XCTestCase

@end

@implementation Implementing_Navigation_with_UINavigationControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
