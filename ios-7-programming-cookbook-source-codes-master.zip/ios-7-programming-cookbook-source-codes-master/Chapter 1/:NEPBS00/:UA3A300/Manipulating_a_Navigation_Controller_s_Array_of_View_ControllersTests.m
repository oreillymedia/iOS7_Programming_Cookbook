//
//  Manipulating_a_Navigation_Controller_s_Array_of_View_ControllersTests.m
//  Manipulating a Navigation Controller’s Array of View ControllersTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Manipulating_a_Navigation_Controller_s_Array_of_View_ControllersTests : XCTestCase

@end

@implementation Manipulating_a_Navigation_Controller_s_Array_of_View_ControllersTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
