//
//  Displaying_Long_Lines_of_Text_with_UITextViewTests.m
//  Displaying Long Lines of Text with UITextViewTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Displaying_Long_Lines_of_Text_with_UITextViewTests : XCTestCase

@end

@implementation Displaying_Long_Lines_of_Text_with_UITextViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
