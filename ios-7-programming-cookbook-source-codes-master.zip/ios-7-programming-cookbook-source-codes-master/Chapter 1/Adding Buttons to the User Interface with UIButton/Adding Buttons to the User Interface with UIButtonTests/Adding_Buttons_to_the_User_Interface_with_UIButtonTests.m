//
//  Adding_Buttons_to_the_User_Interface_with_UIButtonTests.m
//  Adding Buttons to the User Interface with UIButtonTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Adding_Buttons_to_the_User_Interface_with_UIButtonTests : XCTestCase

@end

@implementation Adding_Buttons_to_the_User_Interface_with_UIButtonTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
