//
//  Presenting_Master_Detail_Views_with_UISplitViewControllerTests.m
//  Presenting Master-Detail Views with UISplitViewControllerTests
//
//  Created by Vandad NP on 02/07/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Presenting_Master_Detail_Views_with_UISplitViewControllerTests : XCTestCase

@end

@implementation Presenting_Master_Detail_Views_with_UISplitViewControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
