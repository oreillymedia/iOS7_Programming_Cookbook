//
//  Adding_Object_Subscripting_Support_to_Your_Own_ClassesTests.m
//  Adding Object Subscripting Support to Your Own ClassesTests
//
//  Created by Vandad NP on 06/07/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Adding_Object_Subscripting_Support_to_Your_Own_ClassesTests : XCTestCase

@end

@implementation Adding_Object_Subscripting_Support_to_Your_Own_ClassesTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
