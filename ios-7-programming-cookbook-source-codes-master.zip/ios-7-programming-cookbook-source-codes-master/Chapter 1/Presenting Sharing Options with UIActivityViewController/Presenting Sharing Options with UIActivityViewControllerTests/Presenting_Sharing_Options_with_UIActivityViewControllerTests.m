//
//  Presenting_Sharing_Options_with_UIActivityViewControllerTests.m
//  Presenting Sharing Options with UIActivityViewControllerTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Presenting_Sharing_Options_with_UIActivityViewControllerTests : XCTestCase

@end

@implementation Presenting_Sharing_Options_with_UIActivityViewControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
