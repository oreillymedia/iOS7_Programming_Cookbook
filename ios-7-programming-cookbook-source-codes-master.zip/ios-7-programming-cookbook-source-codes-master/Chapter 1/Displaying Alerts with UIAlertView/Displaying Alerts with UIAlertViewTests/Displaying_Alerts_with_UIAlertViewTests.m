//
//  Displaying_Alerts_with_UIAlertViewTests.m
//  Displaying Alerts with UIAlertViewTests
//
//  Created by Vandad NP on 22/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Displaying_Alerts_with_UIAlertViewTests : XCTestCase

@end

@implementation Displaying_Alerts_with_UIAlertViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
