//
//  Constructing_and_Displaying_Styled_TextsTests.m
//  Constructing and Displaying Styled TextsTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Constructing_and_Displaying_Styled_TextsTests : XCTestCase

@end

@implementation Constructing_and_Displaying_Styled_TextsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
