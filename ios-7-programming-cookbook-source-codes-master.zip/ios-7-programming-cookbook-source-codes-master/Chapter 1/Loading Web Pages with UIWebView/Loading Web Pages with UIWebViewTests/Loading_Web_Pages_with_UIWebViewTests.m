//
//  Loading_Web_Pages_with_UIWebViewTests.m
//  Loading Web Pages with UIWebViewTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Loading_Web_Pages_with_UIWebViewTests : XCTestCase

@end

@implementation Loading_Web_Pages_with_UIWebViewTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
