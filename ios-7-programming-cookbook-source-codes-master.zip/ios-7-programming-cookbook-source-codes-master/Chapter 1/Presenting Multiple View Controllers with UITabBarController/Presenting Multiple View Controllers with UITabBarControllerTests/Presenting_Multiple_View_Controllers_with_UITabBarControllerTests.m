//
//  Presenting_Multiple_View_Controllers_with_UITabBarControllerTests.m
//  Presenting Multiple View Controllers with UITabBarControllerTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Presenting_Multiple_View_Controllers_with_UITabBarControllerTests : XCTestCase

@end

@implementation Presenting_Multiple_View_Controllers_with_UITabBarControllerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
