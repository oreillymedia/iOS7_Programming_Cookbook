//
//  Displaying_Static_Text_with_UILabelTests.m
//  Displaying Static Text with UILabelTests
//
//  Created by Vandad NP on 23/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Displaying_Static_Text_with_UILabelTests : XCTestCase

@end

@implementation Displaying_Static_Text_with_UILabelTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
