//
//  Inserting_a_Group_Entry_into_the_Address_BookTests.m
//  Inserting a Group Entry into the Address BookTests
//
//  Created by Vandad NP on 25/06/2013.
//  Copyright (c) 2013 Pixolity Ltd. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Inserting_a_Group_Entry_into_the_Address_BookTests : XCTestCase

@end

@implementation Inserting_a_Group_Entry_into_the_Address_BookTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
